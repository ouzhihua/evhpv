#' generate sequence length data and output info for sequence with a length over a custom threshold
#' @name fasta_len_filter
#' @param fas sequence file in fasta format;
#' @param min_len minimun length requirement for sequences in ratio;
#' @param full_len full genomic length, optinal. Worked with min_len_ratio;
#' @param min_len_ratio minimun length requirement for sequences in ratio, optional;
#' @return A fasta file with sequences of desired length.
#' @export
#' @author Ou Zhihua
#created by Ou Zhihua on 19 June 2019. Contact:ouzhihua@genomics.cn

#fas <- "hpv16_7000to8500_upto20190725_renamed_extract.fasta"
#min_len <- 7510
#full_len=7905
#min_len_ratio=0.95


fasta_len_filter <- function(fas,  min_len, full_len=NA, min_len_ratio=NA){
  library(Biostrings, warn.conflicts = F)
  library(dplyr, warn.conflicts = F)
  library(stringr, warn.conflicts = F)

  seq <- readDNAStringSet(fas)
  name = names(seq)
  sequence = paste(seq)
  length = width(gsub("[N-]", "", toupper(paste(seq))))

  if(!is.na(min_len_ratio)){
    dfa <- data.frame(name, sequence, length) %>% filter(length > min_len_ratio*full_len)
  }else{
    dfa <- data.frame(name, sequence, length) %>% filter(length > min_len)
    }

  dfa <- dfa %>% arrange(desc(length)) %>%
    mutate(fas = paste0(">", name, "\n", sequence))

  filename <- gsub(".fasta$", "", fas)

  if(!is.na(min_len_ratio)){
    slen <- min_len_ratio
  }else{
    slen <- min_len
  }
  write.table(dfa$fas, paste0(filename, "_", slen, "len.fasta"), sep="", col.name=F, row.names = F, quote=F)
}

