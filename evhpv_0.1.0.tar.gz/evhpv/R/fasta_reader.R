#' Read fasta sequences as data frame.
#' @name fasta_reader
#' @param fas a sequence file in fasta format;
#' @return A data frame of sequences including "name", "sequence", "real_length", "ambigusous_sites";
#' @export
#' @author Ou Zhihua
#created by Ou Zhihua on 19 August 2019. Contact:ouzhihua@genomics.cn


fasta_reader <- function(fas){
  library(Biostrings, warn.conflicts = F)

  seq <- readDNAStringSet(fas)
  name = names(seq)
  sequence = toupper(paste(seq))
  real_length = width(gsub("N", "", gsub("-", "", toupper(paste(seq)))))
  ambiguous_sites = width(gsub("-", "", gsub("[ATCGN~. ]", "", toupper(paste(seq)))))
  dfa <- data.frame(name, sequence, real_length, ambiguous_sites)
  return(dfa)
}

