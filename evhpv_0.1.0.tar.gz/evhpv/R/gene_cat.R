#' concatenate cds of different genes to make pseudo-genomes.
#' @name gene_cat
#' @param files sequence alignment in fasta format to merged, eg, files=c("hpv16_E6.fasta", "hpv16_E7.fasta"). Note that concatenation will be conducted according to the order of the input files and the sequences need to have the same sequence name in files to be concatenated;
#' @param pre prefix for output files;
#' @return contatenated sequences.
#' @export
#' @author Ou Zhihua
#created by Ou Zhihua on 17 May 2019. Contact:ouzhihua@genomics.cn


gene_cat <- function(files, pre){
  library(Biostrings)
  library(dplyr)
  library(stringr)

  alignment <- files[1]
  fas <- readDNAStringSet(alignment)
  name = names(fas)
  seq = toupper(paste(fas))
  length = width(fas)
  ali_length <- as.character(length[1])

  dfa <- data.frame(name, seq)
  colnames(dfa)[2] <- gsub("^.*/", "", alignment)

  k=2
  for (k in 2:length(files)){
    alignment <- files[k]
    fas <- readDNAStringSet(alignment)
    name = names(fas)
    seq = toupper(paste(fas))
    length = width(fas)
    ali_length <- as.character(length[1])

    dfax <- data.frame(name, seq)
    colnames(dfax)[2] <- gsub("^.*/", "", alignment)

    dfa <- inner_join(dfa, dfax, by="name")
    dfa$cat <- paste0(dfa[,2], dfa[,3])
    dfa <- select(dfa, name, cat)
  }

  dfa <- dfa %>%
    mutate(fas = paste0(">", name, "\n", cat))
  write.table(dfa$fas, paste0(pre, "_cat.fasta"), sep="", col.name=F, row.names = F, quote=F)

}

#cat_gene(files=c("hpv16_E4.fasta", "hpv16_E5.fasta", "hpv16_E6.fasta", "hpv16_E7.fasta"), pre="test")
