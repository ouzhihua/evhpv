#' load all packages reqired for the normal function of evhpv package
#' @name load_dependency
#' @examples load_dependency()
#' @return all packages reqired for the normal function of this evhpv package
#' @export
#' @author Ou Zhihua
#created by Ou Zhihua on 12 May 2019. Contact:ouzhihua@genomics.cn

load_dependency <- function(){
  library(phangorn)
  library(dplyr)
  library(ggplot2)
  library(stringr)
  library(tidyr)
  library(ggtree)
}
