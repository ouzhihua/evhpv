#' Trim fasta sequence head and tail.
#' @name fasta_trimer
#' @param fas a sequence file in fasta format;
#' @return trimmed sequences in fasta format.
#' @export
#' @author Ou Zhihua
#created by Ou Zhihua on 19 April 2019. Contact:ouzhihua@genomics.cn


fasta_trimmer <- function(fas, start, end){
  library(Biostrings, warn.conflicts = F)
  library(stringr, warn.conflicts = F)
  
  seq <- readDNAStringSet(fas)
  name = names(seq)
  sequence = toupper(paste(seq))
  dfa <- data.frame(name, sequence)
  dout <- data.frame()
  for (i in 1:length(dfa$name)){
    dx <- dfa[i,]
    dx$seqx <- substr(dx$sequence, start, end)
    dx <- dx %>% mutate(fas=paste0(">", name, "\n", seqx)) %>% select(fas)
    dout <- rbind(dout, dx)
  }
  write.table(dout$fas, paste0(fas, "_", start, "to", end, ".fasta"), col.names = F, row.names = F, quote=F)
}
