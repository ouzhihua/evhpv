#' remove unique or highly similar sequences.
#' @name fasta_unique
#' @description  remove identical sequences.
#' @param myseq sequence alignment in fasta format;
#' @param min_len minimal sequence length requirement;
#' @examples file <- system.file("extdata/hpv18.fasta", package = "evhpv")
#' @examples unique_seq(myseq = file, min_len=7200)
#' @return a fasta file
#' @export
#' @author Ou Zhihua
#created by Ou Zhihua on 09 May 2019. Contact:ouzhihua@genomics.cn


fasta_unique <- function(myseq, min_len){
  library(dplyr)
  library(Biostrings)

  fas <- readDNAStringSet(myseq)
  name = names(fas)
  sequence = toupper(paste(fas))
  length = width(gsub("-", "", fas))

  dfa <- data.frame(name, length, sequence) %>%
    filter(length > min_len) %>%
    select(-length) %>%
    distinct(sequence, .keep_all=T) %>%
    mutate(fas = paste0(">", name, "\n", sequence))

  filename <- gsub(".fasta", "", gsub("^.*/", "", myseq))

  write.table(dfa$fas, paste0(filename, "_uni.fasta"), sep="", col.name=F, row.names = F, quote=F)
}

