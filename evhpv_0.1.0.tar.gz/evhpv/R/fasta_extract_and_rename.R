#' extract sequneces based on sequence names.
#' @name fasta_extract_and_rename
#' @description  extract sequneces based on sequence names provided, the sequence names should be exactly the same in fasta file and index file.
#' @param fas sequences in fasta format;
#' @param info The list of sequence names in csv or file. or a fasta file. Allowed suffix: .txt, .fasta. columname: accession.
#' @param index If a csv or txt file is provided, provide the colum number or colum name of old/index sequence names.
#' @param newname If a csv or txt file is provided and sequences need renaming, provide the colum number or colum name of new sequence names."ori_name" or "fasname".
#' @param outname New name for output fasta file, default is input fasta name with the suffix _extract.
#' @return A fasta file;
#' @export
#' @author Ou Zhihua
#created by Ou Zhihua on 31 May 2019. Contact:ouzhihua@genomics.cn

#fas <- "hpv16_7000to8500_upto20190725_renamed.fasta"
#info <- "hpv16_7000to8500_upto20190725_clean_info.csv"
#index <- "accession"
#newname <- "fasname"

fasta_extract_and_rename <- function(fas, info, index, newname, outfile=NA){
  library(Biostrings, warn.conflicts = F)
  library(dplyr, warn.conflicts = F)
  library(stringr, warn.conflicts = F)

  seq <- readDNAStringSet(fas)
  ori_name = names(seq)
  sequence = paste(seq)
  dfa <- data.frame(ori_name, sequence)
  dfa$name <- str_split_fixed(gsub("[ .]", "|", dfa$ori_name), "\\|", 2)[,1]

  if(grepl("txt", info) == TRUE){
    if(newname=="ori_name"){
      idx <- read.table(info, header=T, sep="\t") %>% select(index)
      colnames(idx)[1] <- "name"
    }else{
      idx <- read.table(info, header=T, sep="\t") %>% select(index, newname)
      colnames(idx) <- c("name", "fasname")
    }
    } else if (grepl("csv", info) == TRUE){
      if(newname=="ori_name"){
        idx <- read.csv(info, header=T) %>% select(index)
        colnames(idx)[1] <- "name"
        }else{
          idx <- read.csv(info, header=T) %>% select(index, newname)
          colnames(idx) <- c("name", "fasname")
        }

    } else {
      infas <- readDNAStringSet(info)
      idx <- data.frame(names(infas))
      colnames(idx) <- "name"
  }



  dout <- inner_join(idx, dfa, by="name") %>% distinct(name, .keep_all=T)

  if(newname=="ori_name"){
    seq_out <- dout %>%
      mutate(fas = paste0(">", ori_name, "\n", sequence))
  }else{
    seq_out <- dout %>%
      mutate(fas = paste0(">", fasname, "\n", sequence))
  }

  if (is.na(outfile)){
    outfile <- paste0(gsub(".fasta", "", gsub("^.*/", "", fas)), "_extract.fasta")
  }

  write.table(seq_out$fas, outfile, sep="", col.name=F, row.names = F, quote=F)

  #output related seqQt info for not matched
  not.match <- anti_join(idx, dfa, by="name")

  if(nrow(not.match)!=0){
    print(paste0(length(not.match$name), " record not matched~~~~"))
    write.csv(not.match, paste0(outfile, "_no_match_list.csv"),row.names=F,quote=TRUE)
  }else{
    print(paste0(fas, ": Well Done! Congratulations!"))
  }


}
