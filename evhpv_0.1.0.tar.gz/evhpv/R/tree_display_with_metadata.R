#' display tree along with metadata
#' @name tree_display_with_metadata
#' @param iqtree input iqtree file with UFB values;
#' @param UFBthreshold minimum Ultrafast Boostrap value for display;
#' @param scale_x position x for scale label, default value is 0.001;
#' @param scale_y position y for scale label, default value is 50;
#' @param metadata a csv file containing meta data, the sequence name should be exactly the same with name in tree, except that the character "|".
#' @param x the number index of sequence name in the metadata file;
#' @param y the number index of target metadata in the metadata file;
#' @param outname prefix for output files;
#' @param h_ratio ratio of plot height, this is used to adjust the height of output plot, default=1;
#' @return phylogeny with associated metadata displayed by color;
#' @export
#' @author Ou Zhihua
#created by Ou Zhihua on 19 June 2019. Contact:ouzhihua@genomics.cn



tree_display_with_metadata <- function(iqtree, UFBthreshold, scale_x=0.001, scale_y=50, metadata, x, y, outname, h_ratio=1){
  library(phangorn)
  library(dplyr)
  library(ggplot2)
  library(stringr)
  library(ggtree)

  # reread tree
  tree <- read.tree(iqtree)
  tree <- midpoint(tree)
  tree <- reorder(tree) #better reorder


  # separate sublineage taxa
  ref <- grep("ref", tree$tip.label, value=T)
  if(length(ref)==0){
    ref <- grep("^HPV", tree$tip.label, value=T)
  }

  bgi <- grep("NODE", tree$tip.label, value=T)
  n_other <- length(tree$tip.label) - length(ref) - length(bgi)

  # get sublineage for sublineageOTU
  df <- read.csv(metadata, header=T, na.strings =c("", NA), stringsAsFactors = F) %>% select(x,y)
  colnames(df) <- c("taxa", "sublineage")
  df <- df %>% filter(!is.na(sublineage))
  df$taxa <- gsub("\\|", "_", df$taxa)
  dfx <- as.data.frame(tree$tip.label)
  colnames(dfx) <- "taxa"
  dfx <- anti_join(dfx, df, by="taxa") %>% mutate(sublineage="undetermined")
  df <- rbind(df, dfx)
  sublineage_set <- sort(unique(df$sublineage))
  sublineage_list <- list()
  for (i in 1:length(sublineage_set)){
    data <- df %>% filter(sublineage==sublineage_set[i])
    sublineage_list[[i]] <- data$taxa
  }


  # sublineage taxa
  tree <- groupOTU(tree, sublineage_list)


  # display tree
  p <- ggtree(tree) +
    geom_tiplab(aes(color=group, na.value="gray"), size=2.5) +
    geom_text2(aes(subset=!isTip&as.numeric(label)>UFBthreshold, label=label), color="black", size=2, hjust=1, vjust=1) +
    geom_treescale(x=scale_x, y=scale_y, width=0.001) +
    ggtitle(paste0(iqtree,"_", "ref", length(ref), "_bgi", length(bgi), "_other", n_other, "_", Sys.Date())) +
    geom_cladelabel(node=10, label="test", align=TRUE, angle=90, barsize=10, fontsize = 2, color='white', offset = 0.01) # this is used to help keep the tree in a narrow shape
#p

  # display ref with tippoint
  ref_label <- data.frame(ref)
  colnames(ref_label)[1] <- "taxa"
  ref_label$source <- "ref"

  if(length(bgi)>0){
    bgi_label <- data.frame(bgi)
    colnames(bgi_label)[1] <- "taxa"
    bgi_label$source <- "bgi"
    shape_label <- rbind(ref_label, bgi_label)
  }

  if(n_other==0 | length(bgi)==0){
    shape_label <- ref_label
  }else{
    shape_label <- rbind(ref_label, bgi_label)
    }


  p2 <- p %<+% shape_label + geom_tippoint(aes(shape=source, size=source), size=3, na.rm = T) +
    scale_color_discrete("sublineages", labels=sublineage_set) +
    guides(color=guide_legend(order=1,ncol=1,byrow=TRUE,reverse = FALSE,override.aes = list(size = 6))) +
    scale_shape_discrete("source") +
    guides(shape=guide_legend(order=2,ncol=1,byrow=TRUE,reverse = FALSE,override.aes = list(size = 4))) +
    theme(legend.position = "left")

  width = 8
  height = max(8, 8*length(tree$tip.label)/50)*h_ratio

  print(p2)
  ggsave(paste0(outname,"_", "ref", length(ref), "_bgi", length(bgi), "_other", n_other, ".pdf"), width=width, height=height, units="in", device="pdf", limitsize = FALSE)
  dev.off()

}


#display_tree_with_metadata(iqtree <- "GTRtree/nwk/HPV16_fg.nwk", UFBthreshold=70,
       #                    metadata="phy_alignments/HPV16_fg_len_over7850.csv", x=1, y=3,
       #                    outname <- "GTRtree/sublineage/HPV16_fg_len_over7850")
