#' To remove gaps or ambiguous sites from sequences.
#' @name fasta_replacer
#' @param fas a sequence file in fasta format;
#' @param removeN whether to remove N from the sequences or not, default is FALSE.
#' @param removeNonATCG whether to remove non-ATCG from the sequences or not, default is FALSE.
#' @return A data frame of sequences;
#' @export
#' @author Ou Zhihua
#created by Ou Zhihua on Jan 4, 2020. Contact:ouzhihua@genomics.cn


fasta_replacer <- function(fas, removeN=F, removeNonATCG=F){
  library(Biostrings, warn.conflicts = F)

  seq <- readDNAStringSet(fas)
  name = names(seq)
  sequence = toupper(paste(seq))
  sequence = gsub("[.~-]", "", toupper(paste(seq)))

  dfa <- data.frame(name, sequence)

  if(removeN==1){
   dfa$sequence <- gsub("N", "", dfa$sequence)
  }

  if(removeNonATCG==1){
    dfa$sequence <- gsub("[RYSWKMBDHV]", "", dfa$sequence)
  }

  dfa <- dfa %>%
    mutate(fas=paste0(">", name, "\n", sequence))
  write.table(dfa$fas, paste0(fas, "_gapReplaced.fas"), col.names = F, row.names = F, quote=F)
}
