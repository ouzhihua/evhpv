#' remove unique or highly similar sequences.
#' @name fasta_reduce
#' @description  remove unique or highly similar sequences by defining minimal different nucleotides based on aligned and trimmed fasta files which may include ref, ncbi and bgi sequences.
#' @param myseq sequence alignment in fasta format;
#' @param min_len minimal sequence length requirement, default=100;
#' @param ndiff minimal different nucleotides requirment;
#' @param sort whether reversely sort sequence by length before deduplication;
#' @examples file <- system.file("extdata/hpv18.fasta", package = "seqphy")
#' @examples reduce_seq(myseq = file, min_len=7200, ndiff=15)
#' @return a fasta file;
#' @export
#' @author Ou Zhihua
#created by Ou Zhihua on 09 May 2019. Contact:ouzhihua@genomics.cn

library(Biostrings)
library(dplyr)
library(stringr)


# list_string_diff copy from web https://www.jianshu.com/p/8b87cf14c6bc

list_string_diff <- function(a, b, sortl, exclude = c("-", "?"), ignore.case = TRUE, show.excluded = FALSE, only.position = TRUE){
  if(nchar(a)!=nchar(b)) stop("Lengths of input strings differ")
  if(ignore.case){
    a = toupper(a)
    b = toupper(b)
  }

  split_seqs = strsplit(c(a, b), split = "")
  only.diff = split_seqs[[1]] != split_seqs[[2]]
  only.diff[
    (split_seqs[[1]] %in% exclude) |
      (split_seqs[[2]] %in% exclude)
    ] = NA

  diff.info = data.frame(which(is.na(only.diff)|only.diff),
                         split_seqs[[1]][only.diff], split_seqs[[2]][only.diff])
  names(diff.info) = c("position", "seq.a", "seq.b")

  if(!show.excluded) diff.info = na.omit(diff.info)
  if(only.position){
    diff.info$position
  }else diff.info
}


# ndiff <- 15
# dfa <- ref
exclude_similar_seq <- function(dfa, ndiff, sortl){
  # dfa: dataframe contain three columns: name/sequence/length
  # ndiff: number of nucleotide difference between pairwise comparison
  # only compare one round

  if (sortl==T){
    dfa <- dfa %>% arrange(desc(length))
  }
  dfa <- dfa %>%
    mutate(selection=NA)
  dfa$selection[1] <- "yes"

  # first round deduplication
  a1 <- as.character(dfa$sequence[1])

  for (i in 2:length(dfa$sequence)) {
    b <- as.character(dfa$sequence[i])
    df <- list_string_diff(a1, b, exclude = c("-", "?"), only.position = T)
    if(length(df) > ndiff){
      dfa$selection[i] <- "yes"
    } else{
      dfa$selection[i] <- "no"
    }
  }

  # next round deduplication
  j=2
  while (j < length(dfa$sequence)) {

    if(as.character(dfa$selection[j]) == "yes"){
      a <- as.character(dfa$sequence[j])

      for (k in (j+1):length(dfa$sequence)){
        if(as.character(dfa$selection[k]) == "yes"){
          b <- as.character(dfa$sequence[k])

          df <- list_string_diff(a, b, exclude = c("-", "?"), only.position = T)

          if(length(df) > ndiff){
            dfa$selection[k] <- "yes"
          } else{
            dfa$selection[k] <- "no"
          }

        }
      }

      j=j+1

    }else{
      j=j+1
    }
  }
    return(dfa)
}



fasta_reduce <- function(myseq, min_len=100, ndiff, sortl=F){
  fas <- readDNAStringSet(myseq)
  name = names(fas)
  sequence = paste(fas)
  length = width(gsub("[N-]", "", fas))

  dfa <- data.frame(name, length, sequence) %>%
    filter(length > min_len)

  seq_out <- exclude_similar_seq(dfa=dfa, ndiff=ndiff, sort=sortl)


  seq_out <- seq_out %>%
    filter(selection == "yes") %>%
    mutate(fas = paste0(">", name, "\n", sequence))

  filename <- gsub(".fasta", "", gsub("^.*/", "", myseq))

  write.table(seq_out$fas, paste0(filename, "_ndif", ndiff, ".fasta"), sep="", col.name=F, row.names = F, quote=F)
}


#fasta_reduce(myseq="hpv18_extract_align.fasta", min_len=7000, ndiff=15, sortl=F)

